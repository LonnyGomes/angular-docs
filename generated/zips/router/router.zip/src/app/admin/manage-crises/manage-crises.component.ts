import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-crises',
  templateUrl: './manage-crises.component.html',
  styleUrls: ['./manage-crises.component.css']
})
export class ManageCrisesComponent { }
