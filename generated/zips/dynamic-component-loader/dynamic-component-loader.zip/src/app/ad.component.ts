export interface AdComponent {
  data: any;
}
