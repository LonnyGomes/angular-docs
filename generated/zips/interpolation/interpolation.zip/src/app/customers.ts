import { Customer } from './customer';

export const CUSTOMERS: Customer[] = [
  { name: 'Maria' },
  { name: 'Oliver' },
  { name: 'Walter' },
  { name: 'Lakshmi' },
  { name: 'Yasha' }
];
